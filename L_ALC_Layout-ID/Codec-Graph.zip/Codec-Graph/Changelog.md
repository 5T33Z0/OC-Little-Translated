CodecGraph Changelog
==================

#### V1.2
- Updated installing Graphviz instructions
- Fixed the license
- Fixed crash when the codec dump file path contains spaces
- Updated the main script to Python3 

#### v1.1
- auto creating of the output and temp folders
- auto removal of the temp folder
#### v1.0
- First stable release. Still a lot of work needs to be done by completely rewriting the main script to python3.

- Added decimal dumps
- Added a hex2dec script
- Added a scripts folder
- Added a tmp folder to store the dotfile
- Auto removal of the dotfile

#### v0.9
- Initial pre-release
