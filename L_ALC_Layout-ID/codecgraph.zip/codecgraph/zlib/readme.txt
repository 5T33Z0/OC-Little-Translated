zlib.pl Commands

For unpacking (examples):

perl zlib.pl inflate layout18.xml.zlib > layout28.xml
perl zlib.pl inflate Platforms18.xml.zlib> Platforms18.xml

For compressing (examples:

perl zlib.pl deflate layout18.xml > layout28.xml.zlib
perl zlib.pl deflate Platforms18.xml> Platforms18.xml.zlib